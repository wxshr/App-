//
//  TaskManager.h
//  Demo
//
//  Created by mingle on 2025/5/20.
//

#import <Foundation/Foundation.h>
#import "MyTask.h"
NS_ASSUME_NONNULL_BEGIN

@class TaskManager;
@protocol TaskManagerDataSource <NSObject>

- (NSUInteger)taskCounts;

- (MyTask *)taskForIndex:(NSUInteger)index;

@end

@protocol TaskManagerDelegate <NSObject>

- (void)taskManager:(TaskManager *)manager willStartTask:(MyTask *)task;
- (void)taskManager:(TaskManager *)manager didCompletionTask:(MyTask *)task;

@end

@interface TaskManager : NSObject

@property(nonatomic, weak) id<TaskManagerDataSource> dataSource;
@property(nonatomic, weak) id<TaskManagerDelegate> delegate;

- (void)start;


@end

NS_ASSUME_NONNULL_END
