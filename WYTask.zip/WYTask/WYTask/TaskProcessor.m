#import "TaskProtocol.h"

@interface TaskProcessor : NSObject <TaskDataProvider, TaskOperationDelegate>
@property (strong, nonatomic) NSMutableArray<NSString *> *taskList;
@property (strong, nonatomic) NSMutableArray<NSNumber *> *completionStatus;
@end

@implementation TaskProcessor

- (instancetype)init {
    self = [super init];
    if (self) {
        _taskList = [@[@"复习iOS基础", @"调试项目代码"] mutableCopy];
        _completionStatus = [@[@NO, @NO] mutableCopy];
    }
    return self;
}

#pragma mark - 数据提供
- (NSInteger)totalTasks {
    return self.taskList.count;
}

- (NSString *)taskNameAtIndex:(NSInteger)index {
    return index < self.taskList.count ? self.taskList[index] : @"";
}

- (BOOL)checkCompletionAtIndex:(NSInteger)index {
    return index < self.completionStatus.count ? [self.completionStatus[index] boolValue] : NO;
}

#pragma mark - 操作代理
- (void)changeTaskState:(NSInteger)index {
    if (index < self.completionStatus.count) {
        BOOL current = [self.completionStatus[index] boolValue];
        self.completionStatus[index] = @(!current);
        NSLog(@"[操作日志] %@ 状态变更为：%@",
             self.taskList[index],
             current ? @"未完成" : @"已完成");
    }
}

- (void)insertNewTask:(NSString *)taskName {
    [self.taskList addObject:taskName];
    [self.completionStatus addObject:@NO];
    NSLog(@"[操作日志] 成功添加：%@", taskName);
}

@end
