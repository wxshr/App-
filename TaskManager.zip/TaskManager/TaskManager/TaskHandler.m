#import "TaskHandler.h"

@implementation TaskHandler

- (instancetype)initWithDefaultTasks {
    self = [super init];
    if (self) {
        _tasks = [@[@"学习逆向工程", @"阅读Apple文档"] mutableCopy];
        _taskStatus = [@[@NO, @NO] mutableCopy];
    }
    return self;
}

#pragma mark - DataSource
- (NSUInteger)numberOfTasks {
    return self.tasks.count;
}

- (NSString *)taskTitleAtIndex:(NSUInteger)index {
    return self.tasks[index];
}

- (BOOL)isTaskCompletedAtIndex:(NSUInteger)index {
    return [self.taskStatus[index] boolValue];
}

#pragma mark - Delegate
- (void)didUpdateTaskStatusAtIndex:(NSUInteger)index completed:(BOOL)completed {
    if (index < self.taskStatus.count) {
        self.taskStatus[index] = @(completed);
        NSLog(@"[系统] 任务状态更新：%@ → %@",
              self.tasks[index],
              completed ? @"✅ 完成" : @"⚪️ 未完成");
    }
}

- (void)didAddNewTaskWithTitle:(NSString *)title {
    [self.tasks addObject:title];
    [self.taskStatus addObject:@NO];
    NSLog(@"[系统] 已添加新任务：%@", title);
}

@end
