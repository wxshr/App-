#import <Foundation/Foundation.h>
#import "TaskHandler.h"

// 辅助函数声明
void printHelp(void);
void printTasks(id<TaskManagerDataSource> dataSource);

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        TaskHandler *handler = [[TaskHandler alloc] initWithDefaultTasks];
        NSLog(@"🚀 任务管理器启动（输入 help 查看命令）");
        
        // 命令循环
        while (YES) {
            char input[100];
            printf("\n> ");
            fgets(input, 100, stdin);
            NSString *command = [[NSString stringWithUTF8String:input] stringByTrimmingCharactersInSet:
                                [NSCharacterSet whitespaceAndNewlineCharacterSet]];
            
            if ([command isEqualToString:@"exit"]) {
                NSLog(@"👋 再见！");
                break;
            } else if ([command isEqualToString:@"help"]) {
                printHelp();
            } else if ([command isEqualToString:@"list"]) {
                printTasks(handler);
            } else if ([command hasPrefix:@"toggle "]) {
                NSInteger index = [[command substringFromIndex:6] integerValue];
                if (index < [handler numberOfTasks]) {
                    BOOL currentStatus = [handler isTaskCompletedAtIndex:index];
                    [handler didUpdateTaskStatusAtIndex:index completed:!currentStatus];
                    printTasks(handler);
                } else {
                    NSLog(@"⚠️ 无效的任务索引");
                }
            } else if ([command hasPrefix:@"add "]) {
                NSString *task = [command substringFromIndex:4];
                if (task.length > 0) {
                    [handler didAddNewTaskWithTitle:task];
                    printTasks(handler);
                } else {
                    NSLog(@"⚠️ 任务内容不能为空");
                }
            } else {
                NSLog(@"⚠️ 未知命令，输入 help 查看可用命令");
            }
        }
    }
    return 0;
}

// 辅助函数实现
void printHelp() {
    NSLog(@"\n可用命令：");
    NSLog(@"  list      - 显示所有任务");
    NSLog(@"  toggle N  - 切换第N个任务状态（从0开始计数）");
    NSLog(@"  add TASK  - 添加新任务（例如：add 吃饭）");
    NSLog(@"  exit      - 退出程序");
}

void printTasks(id<TaskManagerDataSource> dataSource) {
    NSLog(@"\n当前任务列表：");
    for (int i = 0; i < [dataSource numberOfTasks]; i++) {
        NSString *status = [dataSource isTaskCompletedAtIndex:i] ? @"✅" : @"⚪️";
        NSLog(@"%d. %@ %@", i, status, [dataSource taskTitleAtIndex:i]);
    }
}
