//
//  main.m
//  HelloWorld
//
//  Created by mingle on 2025/5/20.
//

#import <Foundation/Foundation.h>

struct Padding {
    float top;
    float bottom;
    float left;
    float right;
};

typedef enum : NSUInteger {
    Men = 10,
    Women
} Sex;

// 返回值类型 函数名称(类型1 参数名1, ...);

int add(int num1, int num2);

int add(int num1, int num2) {
    int result = num1 + num2;
    return result;
}

void performTask(const char *taskName, void (*completion)(const char *name)) {
    printf("开始执行任务%s", taskName);
    sleep(2);
    completion(taskName);
}

void myTaskCompletion(const char *name) {
    printf("任务执行完成 %s", name);
}

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
//        NSLog(@"Hello, World!");
//        int age = 20;
//        char *name = "Tom";
//        bool isSigned = true;
//        double balance = 100.1;
//        Sex sex = Men;
////      表达式1 ? 表达式2 : 表达式3
//        printf("name:%s\nSex:%s\nage:%d\nisSigned:%s\nbalance:%lf\n", name, sex==Men?"男":"女", age, isSigned?"已签到":"未签到", balance);
//        
//        printf("Men=%lu  Women=%lu\n", Men, (unsigned long)Women);
//        
//        struct Padding myPadding = { 1, 2, 3, 4 };
////        myPadding.top = 1;
////        myPadding.bottom = 2;
////        myPadding.left = 3;
////        myPadding.right = 4;
//        printf("top:%f bototm:%f left=%f right=%f\n", myPadding.top, myPadding.bottom, myPadding.left, myPadding.right);
//        
//        printf("2+3 = %d\n", add(2, 3));
//        
//        int num1 = 10;
//        int num2 = num1;
//        num1 = 11;
//        printf("num1=%d   num2=%d\n", num1, num2);
//        int *num1Ptr = &num1;
//        int *num3Ptr = num1Ptr;
//        
//        *num1Ptr = 20;
//        printf("*num1Ptr=%d  *num3Ptr=%d\n", *num1Ptr, *num3Ptr);
//        
////         if  - else if - else
//        
//        performTask("下载文件", myTaskCompletion);
        
//        char username[20];
//        char password[20];
//        printf("用户名：");
//        fgets(username, sizeof(username), stdin);
//        username[strcspn(username, "\n")] = '\0';
//        
//        printf("密码：");
//        fgets(password, sizeof(password), stdin);
//        password[strcspn(password, "\n")] = '\0';
//        printf("输入的用户名是%s\n", username);
//        printf("输入的密码是%s\n", password);
//        if (strcmp(username, "admin") == 0 && strcmp(password, "123456") == 0) {
//            printf("登录成功\n");
//            printf("请选择您要使用的功能：\n");
//            printf("[1] 听歌\n");
//            printf("[2] 看电影\n");
//            printf("[3] 学习\n");
//            char select[10];
//            fgets(select, 10, stdin);
////            if (select[0] == '1') {
////                printf("您选择听歌\n");
////            } else if (select[0] == '2') {
////                printf("您选择看电影\n");
////            } else if (select[0] == '3') {
////                printf("您选择学习\n");
////            } else {
////                printf("不支持 %s", select);
////            }
//            
////            switch (select[0]) {
////                case '1':
////                    printf("您选择听歌\n");
////                    break;
////                case '2':
////                    printf("您选择看电影\n");
////                    break;
////                case '3':
////                    printf("您选择学习\n");
////                    break;
////                default:
////                    printf("不支持 %s", select);
////                    break;
////            }
////            for
////            while
////            do while
//            
//        } else {
//            printf("登录失败");
//        }
        
//        for (int i = 0; i <= 10; i++) {
//            printf("%d ", i);
//        }
        
//        int i = 0;
//        while (++i <= 10) {
//            printf("%d ", i);
////            i++;
//        }
        
//        int i = 0;
//        do {
//            printf("%d ", i);
//        } while (++i <= 10);
    }
    return 0;
}
