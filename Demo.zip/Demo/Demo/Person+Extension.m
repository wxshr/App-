//
//  Person+Extension.m
//  Demo
//
//  Created by mingle on 2025/5/20.
//

#import "Person+Extension.h"

@implementation Person (Extension)

- (void)playGameWithCompletion:(void (^)(NSString *name))completion {
    NSLog(@"%@正在玩游戏", self.name);
    sleep(2);
    completion(self.name);
}

@end
