// TaskProcessor.h
#import <Foundation/Foundation.h>
#import "TaskProtocol.h"

@interface TaskProcessor : NSObject <TaskDataProvider, TaskOperationDelegate>
@property (strong, nonatomic) NSMutableArray<NSString *> *taskList;
@property (strong, nonatomic) NSMutableArray<NSNumber *> *completionStatus;
@end
