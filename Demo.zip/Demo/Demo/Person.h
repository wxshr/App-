//
//  Person.h
//  Demo
//
//  Created by mingle on 2025/5/20.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Person : NSObject {
//    int _age;
}

// weak 修饰的对象被回收之后会设置为 nil, assign修改的对象被回收之后仍然会指向原本的内存地址，再次访问会触发内存错误 0x100012345
//@property (nonatomic, atomic, assign, strong, weak, readonly, readwrite, copy, class)

// _name  get  set
@property (nonatomic, copy) NSString *name;
@property (nonatomic, assign) char *sex;

//+ (void)methodA;
//+ (Person *)create;
+ (Person *)createPersonWithName:(NSString *)aName sex:(char *)sex;

- (Person *)initWithName:(NSString *)aName sex:(char *)sex;

- (void)setAge:(int)age;

- (void)printInfo;

@end

NS_ASSUME_NONNULL_END
