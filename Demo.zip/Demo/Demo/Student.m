//
//  Student.m
//  Demo
//
//  Created by mingle on 2025/5/20.
//

#import "Student.h"


@interface Student () //<TaskManagerDelegate, TaskManagerDataSource> {

@end

@implementation Student {
    MyTask *_allTask[2];
}

- (void)printInfo {
//    [super printInfo];// self
    NSLog(@"name=%@ sex=%s studentNo=%@", self.name, self.sex, self.studentNo);
}

- (void)study {
//    NSLog(@"%@正在上课", self.name);
    MyTask *task1 = [[MyTask alloc] init];
    task1.taskName = @"学习任务";
    task1.performBlock = ^{
        NSLog(@"正在执行学习任务");
    };
    
    MyTask *task2 = [[MyTask alloc] init];
    task2.taskName = @"作业任务";
    task2.performBlock = ^{
        NSLog(@"正在写作业");
    };
    
    // 返回值类型 (^block名称)(参数类型1 参数名1, 参数类型2 参数名2);
    void (^block1)(int num) = ^(int num) {
        NSLog(@"block1 num = %d", num);
    };
    block1(1);
    
    
    int (^block2)(int num) = ^(int num) {
        return num + 1;
    };
    int retval = block2(2);
    NSLog(@"block2(2) retval = %d", retval);
    
//    _allTask = {task1, task2};
    _allTask[0] = task1;
    _allTask[1] = task2;
    TaskManager *manager = [[TaskManager alloc] init];
    manager.dataSource = self;
    manager.delegate = self;
    [manager start];
}

- (NSUInteger)taskCounts {
    return sizeof(_allTask)/sizeof(MyTask *);
}

- (MyTask *)taskForIndex:(NSUInteger)index {
    MyTask *task = _allTask[index];
    return task;
}

- (void)taskManager:(TaskManager *)manager willStartTask:(MyTask *)task {
    NSLog(@"%@将要执行", task.taskName);
}

- (void)taskManager:(TaskManager *)manager didCompletionTask:(MyTask *)task {
    NSLog(@"%@执行完毕", task.taskName);
}

@end
