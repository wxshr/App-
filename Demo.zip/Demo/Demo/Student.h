//
//  Student.h
//  Demo
//
//  Created by mingle on 2025/5/20.
//

#import "Person.h"
#import "TaskManager.h"
NS_ASSUME_NONNULL_BEGIN

@interface Student : Person <TaskManagerDelegate, TaskManagerDataSource>

@property(nonatomic, strong) NSString *studentNo;

- (void)study;

@end

NS_ASSUME_NONNULL_END
