#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol TaskDataProvider <NSObject>
- (NSInteger)totalTasks;
- (NSString *)taskNameAtIndex:(NSInteger)index;
- (BOOL)checkCompletionAtIndex:(NSInteger)index;
@end

@protocol TaskOperationDelegate <NSObject>
- (void)changeTaskState:(NSInteger)index;
- (void)insertNewTask:(NSString *)taskName;
@end

NS_ASSUME_NONNULL_END
