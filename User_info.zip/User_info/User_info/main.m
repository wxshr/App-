#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // 创建可变数组存储用户信息
        NSMutableArray *usersArray = [NSMutableArray array];
        
        // 设置字符变量控制循环
        char continueInput = 'y';
        
        printf("🌟 用户信息录入系统 🌟\n");
        
        while (continueInput == 'y' || continueInput == 'Y') {
            @autoreleasepool {
                // 创建临时字典存储单个用户信息
                NSMutableDictionary *userDict = [NSMutableDictionary dictionary];
                char userName[100];
                int userAge = 0;
                
                // 清理输入缓冲区
                while (getchar() != '\n');
                
                // 获取用户姓名
                printf("\n请输入姓名: ");
                scanf("%99[^\n]", userName);
                NSString *name = [NSString stringWithUTF8String:userName];
                [userDict setObject:name forKey:@"name"];
                
                // 清理输入缓冲区
                while (getchar() != '\n');
                
                // 获取用户年龄（带有效性验证）
                BOOL validAge = NO;
                do {
                    printf("请输入年龄: ");
                    if (scanf("%d", &userAge) == 1 && userAge > 0) {
                        validAge = YES;
                    } else {
                        printf("⚠ 无效的年龄输入，请重新输入正整数！\n");
                        while (getchar() != '\n'); // 清理错误输入
                    }
                } while (!validAge);
                
                [userDict setObject:@(userAge) forKey:@"age"];
                
                // 将用户字典添加到数组
                [usersArray addObject:[userDict copy]];
                
                // 询问是否继续
                printf("\n是否继续录入？(y/n): ");
                scanf(" %c", &continueInput);
            }
        }
        
        // 文件存储操作
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths firstObject];
        NSString *filePath = [documentsDirectory stringByAppendingPathComponent:@"users.plist"];
        
        // 写入文件并验证结果
        if ([usersArray writeToFile:filePath atomically:YES]) {
            printf("\n✅ 数据已成功保存至：%s\n", [filePath UTF8String]);
            printf("共保存 %lu 条用户记录\n", (unsigned long)usersArray.count);
            
        } else {
            printf("\n⚠ 文件保存失败！\n");
        }
        
        // (可选) 验证读取文件内容
        NSArray *loadedArray = [NSArray arrayWithContentsOfFile:filePath];
        if (loadedArray) {
            printf("\n📖 存储文件内容验证：\n");
            for (NSDictionary *user in loadedArray) {
                printf("姓名：%-20s 年龄：%d\n",
                      [user[@"name"] UTF8String],
                      [user[@"age"] intValue]);
            }
        }
    }
    return 0;
}
