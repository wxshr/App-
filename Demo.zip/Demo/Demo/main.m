//
//  main.m
//  Demo
//
//  Created by mingle on 2025/5/20.
//

#import <Foundation/Foundation.h>
#import "Person.h"
#import "Person+Extension.h"
#import "Student.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
//        NSLog(@"Hello, World!");
//        const char *userName = "admin";
//        const char *password = "123456";
//        char inputUserName[20]; // char *inputUserName
//        char inputPassword[20];
//        
//        printf("请输入用户名：");
//        fgets(inputUserName, sizeof(inputUserName), stdin);
//        inputUserName[strcspn(inputUserName, "\n")] = '\0';
//        printf("请输入密码：");
//        fgets(inputPassword, sizeof(inputPassword), stdin);
//        inputPassword[strcspn(inputPassword, "\n")] = '\0';
//        
//        if (strcmp(inputUserName, userName) == 0 && strcmp(inputPassword, password) == 0) {
//            printf("登录成功\n");
//            for (int row = 0; row < 6; row++) {
//                for (int column = 0; column <= row; column++) {
//                    printf("*");
//                }
//                printf("\n");
//            }
//        } else {
//            printf("登录失败\n");
//        }
        
        NSString *tomName = @"Tom";
        Person *tom = [Person createPersonWithName:tomName sex:"men"];
        NSLog(@"tomName ptr is %p\ntom.name ptr is %p", tomName, tom.name);
//        NSLog(@"name:%@ sex:%s", tom.name, tom.sex);
        [tom printInfo];
        [tom playGameWithCompletion:^(NSString * _Nonnull name) {
            NSLog(@"%@已经退出游戏", name);
        }];
        
        Person *lisa = [[Person alloc] initWithName:@"Lisa" sex:"women"];
//        NSLog(@"name:%@ sex:%s", lisa.name, lisa.sex);
        [lisa printInfo];
//        lisa.height = 170;
//        lisa _age
        
        Student *jack = [[Student alloc] initWithName:@"Jack" sex:"Men"];
        jack.studentNo = @"NO.12312312";
        [jack printInfo];
        [jack study];
    }
    return 0;
}
