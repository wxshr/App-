//
//  Person.m
//  Demo
//
//  Created by mingle on 2025/5/20.
//

#import "Person.h"


@interface Person()

@property (nonatomic, assign) int age;

@end


@implementation Person {
//    int _age;
}
@synthesize name=_name;

+ (Person *)createPersonWithName:(NSString *)aName sex:(char *)sex {
    Person *obj = [[Person alloc] init];
    obj.name = aName;
    obj.sex = sex;
    return obj;
}

- (Person *)initWithName:(NSString *)aName sex:(char *)sex {
    if (self = [super init]) {
//        self.name = aName;
//        self.sex = sex;
        [self setName:aName];
        [self setSex:sex];
    }
    return self;
}

- (void)setAge:(int)age {
    _age = age;
}

- (void)printInfo {
    // self getName
//    NSLog(@"name=%@ sex=%s", [self name], [self sex]);
    NSLog(@"name=%@ sex=%s", _name, _sex);
}

- (void)setName:(NSString *)name {
    _name = [name copy];
}

- (NSString *)name {
    return _name;
}

@end
