#import <Foundation/Foundation.h>
#import "TaskManagerProtocols.h"

NS_ASSUME_NONNULL_BEGIN

@interface TaskHandler : NSObject <TaskManagerDataSource, TaskManagerDelegate>

@property (nonatomic, strong) NSMutableArray<NSString *> *tasks;
@property (nonatomic, strong) NSMutableArray<NSNumber *> *taskStatus;

- (instancetype)initWithDefaultTasks;

@end

NS_ASSUME_NONNULL_END
