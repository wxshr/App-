#ifndef TaskManagerProtocols_h
#define TaskManagerProtocols_h


#endif /* TaskManagerProtocols_h */
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol TaskManagerDataSource <NSObject>
- (NSUInteger)numberOfTasks;
- (NSString *)taskTitleAtIndex:(NSUInteger)index;
- (BOOL)isTaskCompletedAtIndex:(NSUInteger)index;
@end

@protocol TaskManagerDelegate <NSObject>
- (void)didUpdateTaskStatusAtIndex:(NSUInteger)index completed:(BOOL)completed;
- (void)didAddNewTaskWithTitle:(NSString *)title;
@end

NS_ASSUME_NONNULL_END
