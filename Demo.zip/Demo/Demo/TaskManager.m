//
//  TaskManager.m
//  Demo
//
//  Created by mingle on 2025/5/20.
//

#import "TaskManager.h"

@implementation TaskManager

- (void)start {
    NSUInteger count = [self.dataSource taskCounts];
    for (NSUInteger i = 0; i < count; i++) {
        MyTask *task = [self.dataSource taskForIndex:i];
        [self.delegate taskManager:self willStartTask:task];
        task.performBlock();
        [self.delegate taskManager:self didCompletionTask:task];
    }
}

@end
