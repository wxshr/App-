//
//  Person+Extension.h
//  Demo
//
//  Created by mingle on 2025/5/20.
//

#import "Person.h"

NS_ASSUME_NONNULL_BEGIN

@interface Person (Extension)

//@property(nonatomic, assign) float height;

- (void)playGameWithCompletion:(void(^)(NSString *name))completion;

@end

NS_ASSUME_NONNULL_END
