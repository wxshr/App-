//
//  MyTask.h
//  Demo
//
//  Created by mingle on 2025/5/20.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MyTask : NSObject

@property(nonatomic, strong) NSString *taskName;

@property(nonatomic, copy) void (^performBlock)(void);

@end

NS_ASSUME_NONNULL_END
