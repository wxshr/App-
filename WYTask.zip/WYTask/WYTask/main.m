#import <Foundation/Foundation.h>
#import "TaskProtocol.h"
#import "TaskProcessor.h"

void displayHelpMenu(void) {
    NSLog(@"\n支持命令列表：");
    NSLog(@" show-all    - 显示全部事项");
    NSLog(@" switch <序号> - 切换事项状态（示例：switch 1）");
    NSLog(@" create <事项> - 创建新事项（示例：create 写单元测试）");
    NSLog(@" quit       - 退出系统");
}

void displayAllTasks(id<TaskDataProvider> provider) {
    NSLog(@"\n当前事项清单：");
    for (int i = 0; i < [provider totalTasks]; i++) {
        NSString *state = [provider checkCompletionAtIndex:i] ? @"✔️" : @"◻️";
        NSLog(@"%02d. %@ %@", i+1, state, [provider taskNameAtIndex:i]);
    }
}

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        TaskProcessor *processor = [[TaskProcessor alloc] init];
        NSLog(@"🌟 任务管理系统已启动（输入 help 查看指引）");
        
        while (1) {
            char cmd[100];
            printf("\n➜ ");
            fgets(cmd, 100, stdin);
            NSString *input = [[NSString stringWithUTF8String:cmd] stringByTrimmingCharactersInSet:
                             [NSCharacterSet whitespaceAndNewlineCharacterSet]];
            
            if ([input isEqualToString:@"quit"]) {
                NSLog(@"🛑 系统已安全退出");
                break;
            } else if ([input isEqualToString:@"help"]) {
                displayHelpMenu();
            } else if ([input isEqualToString:@"show-all"]) {
                displayAllTasks(processor);
            } else if ([input hasPrefix:@"switch "]) {
                NSString *param = [input substringFromIndex:6];
                NSInteger index = [param integerValue] - 1;
                if (index >= 0 && index < [processor totalTasks]) {
                    [processor changeTaskState:index];
                    displayAllTasks(processor);
                } else {
                    NSLog(@"⚠ 错误：无效的序号");
                }
            } else if ([input hasPrefix:@"create "]) {
                NSString *newTask = [input substringFromIndex:6];
                if (newTask.length > 0) {
                    [processor insertNewTask:newTask];
                    displayAllTasks(processor);
                } else {
                    NSLog(@"⚠ 错误：事项内容不能为空");
                }
            } else {
                NSLog(@"⚠ 未知指令，输入 help 查看支持命令");
            }
        }
    }
    return 0;
}
